#pragma once
//a set of common head file.
#include<iostream>
#include<list>
#include<vector>
#include<sstream>
